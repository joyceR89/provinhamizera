#ifndef _EMPRESA_HPP_
#define _EMPRESA_HPP_

#include "PessoaJuridica.hpp"
#include "Gerente.hpp"
#include "Estagiario.hpp"
#include <iostream>

class Empresa : public PessoaJuridica
{
  public:
  
};
#endif